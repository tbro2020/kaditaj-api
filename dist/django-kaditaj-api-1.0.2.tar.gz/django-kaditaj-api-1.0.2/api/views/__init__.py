from .auto_complete import Autocomplete
from .create import Create
from .detail import Detail
from .list import List